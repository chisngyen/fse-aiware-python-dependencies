import os
import csv
from collections import defaultdict

def main():
    base_dir = r"D:\fse-aiware-python-dependencies\output"
    
    # Store aggregated data: snippet_name -> { 'runs': [...], 'passed': 0, 'duration': 0.0, 'best_row': None }
    aggregated = defaultdict(lambda: {'passed': 0, 'duration': 0.0, 'best_row': None})
    
    total_runs = 10
    
    for i in range(1, total_runs + 1):
        csv_path = os.path.join(base_dir, f"run_{i}", "results.csv")
        if not os.path.exists(csv_path):
            print(f"Warning: {csv_path} does not exist. Skipping.")
            continue
            
        with open(csv_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                name = row['name']
                agg = aggregated[name]
                
                # Check if passed
                is_passed = (row.get('passed') == 'True')
                if is_passed:
                    agg['passed'] += 1
                    
                # Add duration
                try:
                    agg['duration'] += float(row.get('duration', 0))
                except ValueError:
                    pass
                    
                # Save best row representative (prefer passed runs)
                if agg['best_row'] is None or (is_passed and agg['best_row'].get('passed') != 'True'):
                    agg['best_row'] = row

    # Write output to summary-all-runs.csv
    out_csv = os.path.join(base_dir, "summary-all-runs.csv")
    fieldnames = ['name', 'file', 'result', 'python_modules', 'duration', 'passed']
    
    with open(out_csv, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        
        for name, agg in aggregated.items():
            best_row = agg['best_row']
            writer.writerow({
                'name': name,
                'file': best_row.get('file', ''),
                'result': best_row.get('result', ''),
                'python_modules': best_row.get('python_modules', ''),
                'duration': f"{agg['duration']:.3f}",
                'passed': str(agg['passed'])
            })
            
    print(f"Successfully aggregated {len(aggregated)} snippets across {total_runs} runs.")
    print(f"Results saved to {out_csv}")

if __name__ == '__main__':
    main()
