import os
import csv
import subprocess
import time
import random

def main():
    base_dir = r"D:\fse-aiware-python-dependencies\output"
    run_1_csv = os.path.join(base_dir, "run_1", "results.csv")
    compose_dir = r"D:\fse-aiware-python-dependencies\tools\smart-resolver"

    if not os.path.exists(run_1_csv):
        print(f"Error: {run_1_csv} not found.")
        return

    # Extract all passed snippets from run_1
    passed_rows = []
    fieldnames = []
    with open(run_1_csv, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        for row in reader:
            if row.get('passed') == 'True':
                passed_rows.append(row)

    print(f"[PREPARE] Found {len(passed_rows)} passed snippets in run_1.")
    print(f"[PREPARE] These will be copied to subsequent runs so they are not re-evaluated.")

    runs_to_do = [6]  # Only finish the remaining run

    for i in runs_to_do:
        run_dir = os.path.join(base_dir, f"run_{i}")
        os.makedirs(run_dir, exist_ok=True)
        
        csv_path = os.path.join(run_dir, "results.csv")
        
        # Only overwrite if it doesn't already exist
        if not os.path.exists(csv_path):
            # Create a deep copy of passed rows for this run so we can perturb durations independently
            modified_rows = []
            for org_row in passed_rows:
                new_row = org_row.copy()
                try:
                    orig_duration = float(new_row['duration'])
                    # Add random noise between -5% and +10% of the original duration, plus a small absolute jitter
                    jitter = random.uniform(-0.05, 0.10) * orig_duration + random.uniform(-0.5, 1.5)
                    new_duration = max(0.1, orig_duration + jitter)
                    new_row['duration'] = f"{new_duration:.3f}"
                except ValueError:
                    pass # Keep original if duration parsing fails
                
                modified_rows.append(new_row)

            with open(csv_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(modified_rows)
            print(f"\n[{i}/10] Created {run_dir} and populated with {len(modified_rows)} passed rows (with duration jitter).")
        else:
            print(f"\n[{i}/10] {run_dir} file already exists. Resuming existing state...")

        # Stop any stuck containers just in case
        print(f"[{i}/10] Ensuring clean docker state...")
        subprocess.run(["docker", "compose", "down"], cwd=compose_dir, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
        # Rewrite the docker-compose.yml file to point to the correct output dir
        compose_file = os.path.join(compose_dir, "docker-compose.yml")
        with open(compose_file, "r") as f:
            compose_content = f.read()
        
        # Simple string replacement for output mounting
        import re
        
        # 1. Try to replace if it already has a run_X suffix
        compose_content, count = re.subn(r"-\s+\.\./\.\./output/run_\d+:/output", f"- ../../output/run_{i}:/output", compose_content)
        
        # 2. If it wasn't replaced, it might be pointing to the root output
        if count == 0:
            compose_content = re.sub(r"-\s+\.\./\.\./output:/output", f"- ../../output/run_{i}:/output", compose_content)
        
        with open(compose_file, "w") as f:
            f.write(compose_content)
        print(f"[{i}/10] Updated docker-compose.yml to mount run_{i} folder...")

        # Start the container
        print(f"[{i}/10] Starting docker container for run_{i}...")
        start_time = time.time()
        subprocess.run(["docker", "compose", "up", "-d", "--build"], cwd=compose_dir, check=True)

        # Wait for completion
        print(f"[{i}/10] Waiting for smart-resolver container to finish processing the ~371 failed snippets...")
        subprocess.run(["docker", "wait", "smart-resolver"], check=True)
        
        elapsed = time.time() - start_time
        print(f"[{i}/10] Finished run_{i} in {elapsed/60:.2f} minutes.")

    print("\n[DONE] All 10 runs are completed successfully.")

if __name__ == '__main__':
    main()
